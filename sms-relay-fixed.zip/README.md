# SMS Relay Ops — Fixed Package

## Files
  office_relay.py   — Telegram bot + Web API server (COMBINED)
  fb_parser.py      — Firebase parser
  sms_receiver.py   — SMS receiver module
  dashboard/        — Mini App: SMS dashboard (host on any static host)
  verify/           — Mini App: Device verification (host on any static host)

## What was fixed
  - New bot token applied
  - Full Web API server added INTO office_relay.py (aiohttp.web)
  - devices table added to SQLite schema
  - fetch() timeout added to both HTML files (no more infinite loading)

## Endpoints now served by office_relay.py
  GET  /api/stats
  GET  /api/sms/recent?limit=N
  GET  /api/numbers?status=all|hot|standby|offline
  GET  /api/device/check/:tg_id
  POST /api/device/register
  GET  /api/referral/:tg_id
  POST /api/referral/claim

## Railway setup
  - Only run office_relay.py — it starts both the bot AND the API on PORT
  - Set PORT env var (Railway sets this automatically)
  - Update config.js in dashboard/ and verify/ with your Railway URL

## Mini app hosting
  Host dashboard/ and verify/ on any static host (Vercel, Netlify, GitHub Pages)
  Set WEB_APP_URL in Telegram BotFather to your verify/ URL
