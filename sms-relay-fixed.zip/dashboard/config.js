const CONFIG = {
  API_URL : 'https://studious-octo-goggles-production.up.railway.app'
};
