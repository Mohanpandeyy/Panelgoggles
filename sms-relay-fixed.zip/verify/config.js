const CONFIG = {
  API_URL       : 'https://studious-octo-goggles-production.up.railway.app',
  DASHBOARD_URL : 'https://database-fixes--singhanjali4628.replit.app'
};
